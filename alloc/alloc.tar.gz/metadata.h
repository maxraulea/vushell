#ifndef metadata_h
#define metadara_h

#include <unistd.h>

typedef struct obj_metadata{
size_t size;
int is_free;
struct obj_metadata *next;
} obj_metadata;

obj_metadata* FindFreeBlock(size_t size, obj_metadata* heap);

#endif