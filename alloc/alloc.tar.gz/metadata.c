#include "metadata.h"

obj_metadata* FindFreeBlock(size_t size, obj_metadata* heap){

    obj_metadata* memObject = heap;

    while(memObject){
        if(memObject->is_free == 1 && memObject->size >= size){
            return memObject;
        }
        memObject = memObject->next;
    }
    return NULL;
}