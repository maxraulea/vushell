#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>

#include "metadata.h"

#define SBRK_ERROR (void*)-1
#define ALLIGNMENT sizeof(long)

static void* AllocateBlock(size_t size);

obj_metadata *memObjects;

void *mymalloc(size_t size)
{

    int cur, offset;
    obj_metadata *nextObj, *currObj, *freeBlock, *newObject;
    void *userMem, *metaMem, *currMem;

    
    //freeBlock = FindFreeBlock(size, memObjects);
   
    if(freeBlock != NULL){
        freeBlock->is_free = 0;
        return freeBlock + sizeof(obj_metadata);    
    }

    // begin allocation


    // end allocation
    currObj = memObjects;
    nextObj = currObj->next;

    if(currObj != NULL){
    newObject = mem;
    newObject->is_free = 0;
    newObject->size = size;

    while(nextObj){
        currObj = nextObj;
        nextObj = nextObj->next;
    }

    currObj->next = newObject;
    return userMem;

    }else{
        memObjects = mem;
        memObjects->is_free = 0;
        memObjects->size = size;
        return userMem;
    }


}

void *mycalloc(size_t nmemb, size_t size)
{
    void* mem = mymalloc(nmemb * size);
    memset(mem, 0, nmemb * size);
    return mem;
}

void myfree(void *ptr)
{   
    obj_metadata *temp = memObjects;
    temp->is_free = 1;
    //if(ptr - sizeof(obj_metadata) == temp){
     //       temp->is_free = 1;
     //       return;
     //   }

    while(1){
        if(ptr - sizeof(obj_metadata) == temp){
            temp->is_free = 1;
            return;
        }
        if(temp->next){
            temp = temp->next;
        }
        else{
            return;
        }   
    }
    
}

void *myrealloc(void *ptr, size_t size)
{
    return NULL;
}

static void* AllocateBlock(size_t size){

    int cur, offset;
    void *userMem, *metaMem, *currMem;

    size_t reqMem = sizeof(obj_metadata);
    void* mem = sbrk(reqMem);

    if(mem == SBRK_ERROR){
        return NULL;
    }

    cur = (uintptr_t)mem;
    offset = cur % ALLIGNMENT;
    if(offset){
        sbrk(ALLIGNMENT - offset);
    }
    userMem = sbrk(0);

    
    if(sbrk(size) ==  SBRK_ERROR){
        return NULL;
    }
}

/*
 * Enable the code below to enable system allocator support for your allocator.
 * Doing so will make debugging much harder (e.g., using printf may result in
 * infinite loops).
 */
#if 0
void *malloc(size_t size) { return mymalloc(size); }
void *calloc(size_t nmemb, size_t size) { return mycalloc(nmemb, size); }
void *realloc(void *ptr, size_t size) { return myrealloc(ptr, size); }
void free(void *ptr) { myfree(ptr); }
#endif
