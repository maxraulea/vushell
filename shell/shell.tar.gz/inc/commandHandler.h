#ifndef CommandHandler_h
#define CommandHandler_h

#include "../parser/ast.h"

int HandleCommand(node_t *node);

int ExecBinary(node_t *node);

#endif