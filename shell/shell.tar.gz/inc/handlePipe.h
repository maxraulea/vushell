#ifndef handlePipe_h
#define handlePipe_h

#include "../parser/ast.h"

int HandlePipe(node_t *node);

#endif