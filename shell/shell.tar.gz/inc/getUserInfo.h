#ifndef getUserInfo_h
#define getUserInfo_h

#define MAX_BUFFER_SIZE 512

typedef struct
{
    char currentDirectory[MAX_BUFFER_SIZE];
    char  User[MAX_BUFFER_SIZE];
    char  Host[MAX_BUFFER_SIZE];
}UserInfo;

int getUserInfo(UserInfo *userinfo);

int getCommandLinePrompt(char *prompt);


#endif