#include "../inc/commandHandler.h"
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

static int CheckSimpleCommands(node_t *node);

int HandleCommand(node_t *node){
    
    if(!CheckSimpleCommands(node)){
        // Error
        return 0;
    }
    
    pid_t process = fork();
    if (process == 0) {
        if(ExecBinary(node)){
            // Error 
            return 2;
        }
    }
    else {
        waitpid(process, NULL, 0);
    }

    return 0;
}
// returns 0 on succes
// returns 1 for built in not found
// returns 2 on error
static int CheckSimpleCommands(node_t *node){
    char *program = node->command.program;
    char **argv = node->command.argv;

    if(!strcmp(program,"exit")){
        exit(atoi(argv[1]));
        return 0;
    }
    else if (!strcmp(program,"cd")){
        if(chdir(argv[1])){
            printf("there is no such directory %s \n", argv[1]);
            return 2;
        }
        return 0;
    }
    else if (!strcmp(program,"set")){
    
        return 0;
    }
    else if (!strcmp(program,"unset")){

        return 0;
    }
    return 1;
}

int ExecBinary(node_t *node){
    char *program = node->command.program;
    char **argv = node->command.argv;

    if(execvp(program, argv) == -1){
        printf("An error occured \n");
        return 1;
    }

    return 0;   
}
