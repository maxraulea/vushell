#include <unistd.h>
#include <sys/wait.h>
#include "../parser/ast.h"
#include "../inc/commandHandler.h"

#define STDIN 0
#define STDOUT 1

#define PIPE_RD 0
#define PIPE_WR 1

int HandlePipe(node_t *node){

    int nParts = node->pipe.n_parts;
    //ren[nParts];// cat_pid, sort_pid;
    int fd[nParts][2];
    // init the pipes
    for (int i = 0; i < nParts; i++) {
        pipe(fd[i]);
    }

    for (int i = 0; i < nParts; i++) {
        //int PIPE_RD = i * 2;
        //int PIPE_WR = i * 2 + 1;

        pid_t child = fork();
        if (child == 0){

            if (i != nParts - 1){
                // close everything exept pipe wr
                //close(fd[PIPE_RD]);
                close(STDOUT);
                dup(fd[i][PIPE_WR]);
            }

            if (i != 0) { 
              //  for (int j = 0; j < nParts; j++) {
              //     if (j !=i){
              //          close(fd[j][1]);
              //          close(fd[j][0]);
             //       }
              //  }
                close(STDIN);
                dup(fd[i - 1][PIPE_RD]);
            }

                for (int j = 0; j < nParts; j++) {
                    
                    close(fd[j][PIPE_RD]);
                    close(fd[j][PIPE_WR]);
                    
                }
            //close(fd[i][PIPE_RD]);
            //close(fd[i][PIPE_WR]);
            ExecBinary(node->pipe.parts[i]);

            //close(fd[PIPE_WR]);
            //close(fd[PIPE_WR]);

        //HandleCommand(node->pipe.parts[i]);
        }
        
            for (int i = 0; i < nParts; i++) {
                close(fd[i][PIPE_RD]);
                close(fd[i][PIPE_WR]);
            }
            for (int i = 0; i < nParts + 1; i++) {
                wait(NULL);
            }
    }

/*
    cat_pid = fork();
    if ( cat_pid == 0 ) {
        close(fd[PIPE_RD]);
        close(STDOUT);
        dup(fd[PIPE_WR]);
        ExecBinary(node->pipe.parts[0]);
    }    
    sort_pid = fork();
    if ( sort_pid == 0 ) {
        close(fd[PIPE_WR]);
        close(STDIN);
        dup(fd[PIPE_RD]);
        ExecBinary(node->pipe.parts[1]);
    }
    close(fd[PIPE_RD]);
    close(fd[PIPE_WR]);
    /* wait for children to finish */
    /*
    waitpid(cat_pid, NULL, 0);
    waitpid(sort_pid, NULL, 0);

*/

    /*
    int nParts = node->pipe.n_parts;
    int fd[2];
    // init the pipes
    for (int i = 0; i < nParts; i++) {
        pipe(fd);
    }

    for (int i = 0; i < nParts - 1; i++) {
        int PIPE_RD = 0;
        int PIPE_WR = 1;

        pid_t process = fork();
        if (process == 0){

            if (i != nParts - 1){
                close(fd[PIPE_RD]);
                close(STDOUT);
                dup(fd[PIPE_WR]);
            } 
            
            if (i != 0) { 
                close(fd[PIPE_WR]);
                close(STDIN);
                dup(fd[PIPE_RD]);
            }

            //close(fd[PIPE_WR]);
            //close(fd[PIPE_WR]);

            execvp(node->pipe.parts[i]->command.program, node->pipe.parts[i]->command.argv);

        //HandleCommand(node->pipe.parts[i]);
        }
        
        
    }
    close(fd[1]);
    close(fd[0]);
    wait(NULL);
    */

/*
    for (int i = 0; i < nParts * 2; i++) {
        close(fd[i]);
    }*/
    return 0;
    // close the pipe ends that get used as input for the next process and then call the new process 

}