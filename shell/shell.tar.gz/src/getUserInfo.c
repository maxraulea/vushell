#include "../inc/getUserInfo.h"
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <pwd.h>

int getUserInfo(UserInfo *userinfo){
    if(!getcwd(userinfo->currentDirectory, MAX_BUFFER_SIZE)){
        return 1;
    }

    if(gethostname(userinfo->Host, MAX_BUFFER_SIZE)){
        return 1;
    }

    struct passwd *p = getpwuid(getuid());  
    strcpy(userinfo->User, p->pw_name);
    if(!userinfo->User){
       
        return 1;
    }

    return 0;
}

int getCommandLinePrompt(char *prompt){
    UserInfo user;
    
    if(getUserInfo(&user)){
        // error 
    }

    size_t nbytes = snprintf(NULL, 0, "%s@%s %s $ ", user.User, user.Host, user.currentDirectory) + 1;
    if (snprintf(prompt, nbytes, "%s@%s %s $ ", user.User, user.Host, user.currentDirectory) != (int    )nbytes - 1){
        return 1;
    }
    return 0;
}